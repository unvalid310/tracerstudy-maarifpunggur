<?php 

if (!defined('BASEPATH'))
exit('No direct script access allowed');
/*
  |--------------------------------------------------------------------------
  | Website Name
  |--------------------------------------------------------------------------
  |
  |Name of the Website
  |
*/
$config['site_name'] = 'Tracer Study';

/*
  |--------------------------------------------------------------------------
  | Admin Theme
  |--------------------------------------------------------------------------
  |
  |Theme of the Admin Website
  |
*/
$config['_auth_theme'] = 'default';
$config['_alumni_theme'] = 'default';
$config['_instansi_theme'] = 'default';
$config['_admin_theme'] = 'default';
$config['_theme'] = 'default';